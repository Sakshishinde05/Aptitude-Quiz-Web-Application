import { useEffect, useMemo, useState } from "react";
import {
  Activity, ArrowLeft, ArrowRight, Award, BarChart3, BookOpen, Check,
  CheckCircle2, ChevronDown, Clock3, Flame, GraduationCap, Home, Layers3,
  Lightbulb, ListChecks, Menu, RotateCcw, Sparkles, Target, Trophy,
  X, XCircle, Zap
} from "lucide-react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const categories = [
  { name: "All categories", icon: Layers3, description: "A balanced mix of aptitude questions", tone: "violet" },
  { name: "Quantitative Aptitude", icon: BarChart3, description: "Numbers, percentages and arithmetic", tone: "blue" },
  { name: "Logical Reasoning", icon: Lightbulb, description: "Patterns, logic and problem-solving", tone: "orange" },
  { name: "Verbal Ability", icon: BookOpen, description: "Vocabulary and English usage", tone: "green" }
];

const fallbackQuestions = [
  { _id: "starter-1", category: "Quantitative Aptitude", difficulty: "Easy", question: "A product costs ₹800 and is discounted by 15%. What is its selling price?", options: ["₹660", "₹680", "₹700", "₹720"] },
  { _id: "starter-2", category: "Quantitative Aptitude", difficulty: "Easy", question: "What is 35% of 240?", options: ["72", "84", "96", "108"] },
  { _id: "starter-3", category: "Quantitative Aptitude", difficulty: "Medium", question: "A train travels 180 km in 3 hours. What is its average speed?", options: ["45 km/h", "50 km/h", "60 km/h", "65 km/h"] },
  { _id: "starter-4", category: "Logical Reasoning", difficulty: "Easy", question: "Find the next number: 3, 6, 12, 24, __.", options: ["30", "36", "42", "48"] },
  { _id: "starter-5", category: "Logical Reasoning", difficulty: "Easy", question: "Choose the odd one out.", options: ["Square", "Triangle", "Circle", "Table"] },
  { _id: "starter-6", category: "Verbal Ability", difficulty: "Easy", question: "Choose the word closest in meaning to “brief”.", options: ["Lengthy", "Concise", "Unclear", "Complex"] }
];

function formatTime(seconds) {
  const mins = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${mins}:${secs}`;
}

function App() {
  const [view, setView] = useState("home");
  const [selectedCategory, setSelectedCategory] = useState("All categories");
  const [questionCount, setQuestionCount] = useState(10);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(600);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [reviewFilter, setReviewFilter] = useState("all");

  const currentQuestion = questions[currentIndex];
  const answeredCount = Object.keys(answers).length;
  const progress = questions.length ? ((currentIndex + 1) / questions.length) * 100 : 0;
  const correctCount = result?.correct ?? 0;

  useEffect(() => {
    if (view !== "quiz") return undefined;
    if (secondsLeft <= 0) {
      submitQuiz();
      return undefined;
    }
    const timer = window.setInterval(() => setSecondsLeft(value => value - 1), 1000);
    return () => window.clearInterval(timer);
  }, [view, secondsLeft]);

  async function startQuiz() {
    setLoading(true);
    setError("");
    try {
      let data;
      try {
        const response = await fetch(`${API_URL}/questions?category=${encodeURIComponent(selectedCategory)}&limit=${questionCount}`);
        if (!response.ok) throw new Error("Unable to load questions.");
        data = await response.json();
      } catch {
        data = {
          questions: fallbackQuestions.filter(q => selectedCategory === "All categories" || q.category === selectedCategory)
        };
      }
      const nextQuestions = (data.questions || []).slice(0, questionCount);
      if (!nextQuestions.length) throw new Error("No questions are available for this category yet.");
      setQuestions(nextQuestions);
      setAnswers({});
      setCurrentIndex(0);
      setSecondsLeft(nextQuestions.length * 60);
      setResult(null);
      setView("quiz");
    } catch (e) {
      setError(e.message || "Could not start quiz. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function submitQuiz() {
    if (view !== "quiz" || !questions.length) return;
    const payload = questions.map(question => ({
      questionId: question._id,
      selectedAnswer: Number.isInteger(answers[question._id]) ? answers[question._id] : null
    }));
    let computed;
    try {
      const response = await fetch(`${API_URL}/questions/answers`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers: payload })
      });
      if (!response.ok) throw new Error("Scoring endpoint unavailable");
      computed = await response.json();
    } catch {
      computed = {
        total: questions.length,
        correct: 0,
        incorrect: 0,
        scorePercent: 0,
        review: questions.map(question => ({
          questionId: question._id,
          question: question.question,
          options: question.options,
          selectedAnswer: answers[question._id] ?? null,
          correctAnswer: null,
          isCorrect: false,
          explanation: "Connect the backend and seed the question bank to enable answer review.",
          category: question.category
        }))
      };
      setError("The quiz was saved locally, but answer review needs the backend connection.");
    }
    setResult({ ...computed, elapsed: questions.length * 60 - secondsLeft });
    setView("results");
  }

  function leaveQuiz() {
    if (window.confirm("Leave this quiz? Your current answers will be lost.")) {
      setView("home");
      setAnswers({});
      setError("");
    }
  }

  const filteredReview = useMemo(() => {
    if (!result) return [];
    if (reviewFilter === "all") return result.review;
    if (reviewFilter === "correct") return result.review.filter(item => item.isCorrect);
    return result.review.filter(item => !item.isCorrect);
  }, [result, reviewFilter]);

  function resetHome() {
    setView("home");
    setResult(null);
    setAnswers({});
    setError("");
    setMobileMenu(false);
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <button className="brand" onClick={resetHome} aria-label="Elevate home">
          <span className="brand-mark"><Activity size={21} strokeWidth={2.7} /></span>
          <span className="brand-name">elevate<span>.</span><small>APTITUDE STUDIO</small></span>
        </button>

        <div className="side-label">WORKSPACE</div>
        <nav className="side-nav">
          <button className={`nav-item ${view === "home" ? "active" : ""}`} onClick={resetHome}><Home size={18} /> Dashboard</button>
          <button className={`nav-item ${view === "results" ? "active" : ""}`} onClick={() => result && setView("results")}><BarChart3 size={18} /> My results</button>
        </nav>

        <div className="side-label category-label">PRACTICE AREAS</div>
        <nav className="side-nav category-nav">
          {categories.slice(1).map(({ name, icon: Icon, tone }) => (
            <button key={name} className={`nav-item ${selectedCategory === name ? "category-active" : ""}`} onClick={() => { setSelectedCategory(name); setView("home"); setMobileMenu(false); }}>
              <span className={`nav-icon ${tone}`}><Icon size={16} /></span><span>{name}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />
        <div className="sidebar-tip">
          <div className="tip-icon"><Sparkles size={17} /></div>
          <p className="tip-title">Small steps, big progress.</p>
          <p className="tip-copy">A little practice every day can make a real difference.</p>
          <button onClick={() => { setSelectedCategory("All categories"); setView("home"); }}>Explore practice <ArrowRight size={14} /></button>
        </div>
        <div className="profile-row">
          <div className="avatar">S</div><div className="profile-info"><strong>Student</strong><span>Practice account</span></div><ChevronDown size={15} className="profile-chevron" />
        </div>
      </aside>

      {mobileMenu && <button className="mobile-overlay" onClick={() => setMobileMenu(false)} aria-label="Close menu" />}

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu-button" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu"><Menu size={21} /></button>
          <div className="breadcrumb">Workspace <span>/</span> <strong>{view === "quiz" ? "Quiz session" : view === "results" ? "Quiz results" : "Dashboard"}</strong></div>
          <div className="topbar-right"><span className="live-dot" /> <span>Practice mode</span><div className="top-avatar">S</div></div>
        </header>

        <div className="page-content">
          {error && <div className="notice"><span>{error}</span><button onClick={() => setError("")} aria-label="Dismiss"><X size={16} /></button></div>}

          {view === "home" && (
            <>
              <section className="welcome-row">
                <div><div className="eyebrow"><Sparkles size={14} /> YOUR LEARNING SPACE</div><h1>Practice with purpose.</h1><p className="page-subtitle">Build your aptitude, one question at a time.</p></div>
                <div className="date-chip"><span className="date-dot" /> Your next breakthrough starts here</div>
              </section>

              <section className="hero-card">
                <div className="hero-content">
                  <div className="hero-pill"><Zap size={13} fill="currentColor" /> YOUR DAILY CHALLENGE</div>
                  <h2>Ready to level up<br />your <span>aptitude skills?</span></h2>
                  <p>Sharpen your thinking, track your progress, and walk into every test with more confidence.</p>
                  <button className="hero-button" onClick={() => { setSelectedCategory("All categories"); startQuiz(); }} disabled={loading}>{loading ? "Preparing your quiz..." : "Start a quick quiz"} <ArrowRight size={17} /></button>
                  <div className="hero-note"><CheckCircle2 size={15} /> No pressure. Just progress.</div>
                </div>
                <div className="hero-visual" aria-hidden="true">
                  <div className="orbit orbit-one" /><div className="orbit orbit-two" />
                  <div className="visual-spark spark-a">✳</div><div className="visual-spark spark-b">✦</div>
                  <div className="visual-card card-back"><div className="mini-bars"><i /><i /><i /><i /><i /><i /><i /></div></div>
                  <div className="visual-card card-front"><div className="card-front-top"><span>YOUR POTENTIAL</span><span className="card-status">+12.8%</span></div><div className="visual-score">86<span>/100</span></div><div className="visual-score-label">Keep your momentum</div><div className="chart-line"><svg viewBox="0 0 240 65" preserveAspectRatio="none"><path d="M0 53 C25 47, 30 56, 50 39 S83 43, 103 28 S132 38, 153 18 S180 30, 198 12 S222 20, 240 4" fill="none" stroke="#8B7CFF" strokeWidth="3" strokeLinecap="round" /><path d="M0 53 C25 47, 30 56, 50 39 S83 43, 103 28 S132 38, 153 18 S180 30, 198 12 S222 20, 240 4 L240 65 L0 65 Z" fill="url(#areaFill)" /><defs><linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8B7CFF" stopOpacity=".22" /><stop offset="100%" stopColor="#8B7CFF" stopOpacity="0" /></linearGradient></defs></svg></div><div className="chart-days"><span>MON</span><span>TUE</span><span>WED</span><span>THU</span><span>FRI</span><span>SAT</span><span>SUN</span></div></div>
                  <div className="floating-badge"><span><Trophy size={16} /></span><div><strong>You're improving!</strong><small>Every session counts</small></div></div>
                </div>
              </section>

              <section className="stats-grid">
                <div className="stat-card"><div className="stat-top"><span>Question bank</span><span className="stat-icon violet-bg"><BookOpen size={17} /></span></div><div className="stat-number">15<span>+</span></div><div className="stat-bottom">Starter questions to explore <span className="stat-trend"><Layers3 size={13} /> 3 subjects</span></div></div>
                <div className="stat-card"><div className="stat-top"><span>Time per question</span><span className="stat-icon blue-bg"><Clock3 size={17} /></span></div><div className="stat-number">60<span> sec</span></div><div className="stat-bottom">Build speed and accuracy <span className="stat-trend blue-text"><Zap size={13} /> Timed</span></div></div>
                <div className="stat-card"><div className="stat-top"><span>Learning focus</span><span className="stat-icon green-bg"><Target size={17} /></span></div><div className="stat-number">3<span> areas</span></div><div className="stat-bottom">Practice a little every day <span className="stat-trend green-text"><Check size={13} /> Your pace</span></div></div>
              </section>

              <section className="section-heading"><div><h2>Choose your practice</h2><p>Pick a subject or mix it up with a full aptitude set.</p></div><span className="section-count">04 CATEGORIES</span></section>
              <section className="category-grid">
                {categories.map(({ name, icon: Icon, description, tone }, index) => (
                  <button key={name} className={`category-card ${selectedCategory === name ? "selected" : ""}`} onClick={() => setSelectedCategory(name)}>
                    <div className={`category-icon ${tone}`}><Icon size={21} /></div><div className="category-title-row"><h3>{name}</h3>{selectedCategory === name && <CheckCircle2 size={17} className="selected-check" />}</div><p>{description}</p><div className="category-card-bottom"><span>{index === 0 ? "Mixed practice" : "Focused practice"}</span><span className="circle-arrow"><ArrowRight size={15} /></span></div>
                  </button>
                ))}
              </section>

              <section className="setup-panel">
                <div className="setup-heading"><div className="setup-icon"><ListChecks size={19} /></div><div><h2>Set up your session</h2><p>Make this practice session work for you.</p></div></div>
                <div className="setup-controls">
                  <label className="field-label">PRACTICE AREA<select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}>{categories.map(category => <option key={category.name}>{category.name}</option>)}</select></label>
                  <label className="field-label">NUMBER OF QUESTIONS<select value={questionCount} onChange={e => setQuestionCount(Number(e.target.value))}><option value={5}>5 questions · Quick</option><option value={10}>10 questions · Standard</option><option value={15}>15 questions · Focus</option><option value={20}>20 questions · Challenge</option></select></label>
                  <button className="primary-button" onClick={startQuiz} disabled={loading}>{loading ? "Loading..." : "Begin practice"} <ArrowRight size={16} /></button>
                </div>
              </section>

              <footer className="page-footer"><span>© 2026 Elevate Aptitude Studio</span><span>Made for your next big opportunity <span className="footer-heart">✦</span></span></footer>
            </>
          )}

          {view === "quiz" && currentQuestion && (
            <section className="quiz-layout">
              <div className="quiz-topline"><button className="back-button" onClick={leaveQuiz}><ArrowLeft size={16} /> Exit quiz</button><div className="quiz-live"><span /> QUIZ IN PROGRESS</div></div>
              <div className="quiz-heading"><div><div className="eyebrow"><GraduationCap size={14} /> FOCUS SESSION</div><h1>You've got this.</h1><p className="page-subtitle">Take your time, read carefully, and trust your thinking.</p></div><div className={`timer-card ${secondsLeft < 60 ? "timer-warning" : ""}`}><Clock3 size={19} /><div><small>TIME REMAINING</small><strong>{formatTime(secondsLeft)}</strong></div></div></div>
              <div className="quiz-progress-card"><div className="progress-meta"><span>YOUR PROGRESS</span><strong>Question {currentIndex + 1} <span>of {questions.length}</span></strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div><div className="progress-bottom"><span>{answeredCount} answered</span><span>{questions.length - answeredCount} remaining</span></div></div>
              <div className="question-card"><div className="question-meta"><span className="question-number">QUESTION {(currentIndex + 1).toString().padStart(2, "0")}</span><span className="difficulty-pill">{currentQuestion.difficulty || "Practice"}</span></div><h2>{currentQuestion.question}</h2><p className="question-instruction">Select one answer from the options below.</p><div className="answer-list">{currentQuestion.options.map((option, index) => { const chosen = answers[currentQuestion._id] === index; return <button key={`${currentQuestion._id}-${index}`} className={`answer-option ${chosen ? "chosen" : ""}`} onClick={() => setAnswers(prev => ({ ...prev, [currentQuestion._id]: index }))}><span className="option-letter">{String.fromCharCode(65 + index)}</span><span className="option-text">{option}</span><span className="option-radio">{chosen && <span />}</span></button>; })}</div><div className="question-card-footer"><span><Lightbulb size={15} /> Choose the best answer</span><span>{answers[currentQuestion._id] !== undefined ? <><CheckCircle2 size={15} className="answered-check" /> Answer selected</> : "Not answered yet"}</span></div></div>
              <div className="quiz-navigation"><button className="secondary-button" onClick={() => setCurrentIndex(i => Math.max(0, i - 1))} disabled={currentIndex === 0}><ArrowLeft size={16} /> Previous</button><div className="question-dots">{questions.map((q, i) => <button key={q._id} aria-label={`Go to question ${i + 1}`} title={`Question ${i + 1}`} className={`${i === currentIndex ? "current" : ""} ${answers[q._id] !== undefined ? "answered" : ""}`} onClick={() => setCurrentIndex(i)} />)}</div>{currentIndex < questions.length - 1 ? <button className="primary-button" onClick={() => setCurrentIndex(i => i + 1)}>Next question <ArrowRight size={16} /></button> : <button className="primary-button submit-button" onClick={submitQuiz}><CheckCircle2 size={16} /> Submit quiz</button>}</div>
              <div className="quiz-disclaimer"><span><Clock3 size={14} /> Your answers are kept during this session.</span><button onClick={submitQuiz}>Finish early</button></div>
            </section>
          )}

          {view === "results" && result && (
            <section className="results-layout">
              <button className="back-button" onClick={resetHome}><ArrowLeft size={16} /> Back to dashboard</button>
              <div className="results-hero"><div className="results-icon"><Award size={29} /></div><div className="eyebrow"><Sparkles size={14} /> SESSION COMPLETE</div><h1>{result.scorePercent >= 80 ? "Outstanding effort!" : result.scorePercent >= 50 ? "Good work. Keep going!" : "Every attempt helps you grow."}</h1><p>Your practice session is complete. Here's a look at how you did.</p><div className="score-ring" style={{ "--score": `${result.scorePercent || 0}%` }}><div><strong>{result.scorePercent ?? 0}%</strong><span>YOUR SCORE</span></div></div><div className="result-metrics"><div><strong>{result.correct}</strong><span>Correct answers</span></div><div><strong>{result.incorrect}</strong><span>Incorrect / skipped</span></div><div><strong>{formatTime(Math.max(0, result.elapsed || 0))}</strong><span>Time used</span></div></div></div>
              <div className="review-heading"><div><h2>Answer review</h2><p>Learn from each question and understand the reasoning.</p></div><button className="secondary-button" onClick={resetHome}><RotateCcw size={15} /> Try again</button></div>
              <div className="review-filters">{[["all", "All questions"], ["correct", "Correct"], ["incorrect", "Review needed"]].map(([value, label]) => <button key={value} className={reviewFilter === value ? "active" : ""} onClick={() => setReviewFilter(value)}>{label}</button>)}</div>
              <div className="review-list">{filteredReview.map((item, index) => <article className="review-card" key={`${item.questionId}-${index}`}><div className={`review-status ${item.isCorrect ? "right" : "wrong"}`}>{item.isCorrect ? <CheckCircle2 size={17} /> : <XCircle size={17} />}</div><div className="review-body"><div className="review-category">{item.category}</div><h3>{item.question}</h3><div className="review-answer-lines"><p><span>Your answer</span><strong className={item.isCorrect ? "correct-text" : "incorrect-text"}>{item.selectedAnswer === null ? "Not answered" : item.options[item.selectedAnswer]}</strong></p>{item.correctAnswer !== null && <p><span>Correct answer</span><strong className="correct-text">{item.options[item.correctAnswer]}</strong></p>}</div><div className="explanation"><Lightbulb size={15} /><span>{item.explanation}</span></div></div></article>)}</div>
              {filteredReview.length === 0 && <div className="empty-review">Nothing to show in this filter yet.</div>}
              <footer className="page-footer"><span>© 2026 Elevate Aptitude Studio</span><span>Progress over perfection <span className="footer-heart">✦</span></span></footer>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
