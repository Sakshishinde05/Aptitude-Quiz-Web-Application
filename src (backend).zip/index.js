import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import questionsRouter from "./routes/questions.js";

const app = express();
const port = Number(process.env.PORT) || 5000;

app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "100kb" }));

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", database: mongoose.connection.readyState === 1 ? "connected" : "fallback mode" });
});

app.use("/api/questions", questionsRouter);

app.use((req, res) => {
  res.status(404).json({ message: "Endpoint not found." });
});

app.use((error, req, res, next) => {
  console.error(error.message);
  res.status(500).json({ message: "Something went wrong on the server." });
});

if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log("MongoDB connected"))
    .catch(error => console.error("MongoDB connection failed; starter questions remain available:", error.message));
}

app.listen(port, () => console.log(`Aptitude Quiz API running on http://localhost:${port}`));
