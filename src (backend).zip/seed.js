import "dotenv/config";
import mongoose from "mongoose";
import Question from "./models/Question.js";
import { starterQuestions } from "./data/questions.js";

if (!process.env.MONGODB_URI) {
  console.error("Set MONGODB_URI in server/.env before seeding.");
  process.exit(1);
}

try {
  await mongoose.connect(process.env.MONGODB_URI);
  await Question.deleteMany({});
  await Question.insertMany(starterQuestions);
  console.log(`Seeded ${starterQuestions.length} questions.`);
} catch (error) {
  console.error("Seeding failed:", error.message);
  process.exitCode = 1;
} finally {
  await mongoose.disconnect();
}
