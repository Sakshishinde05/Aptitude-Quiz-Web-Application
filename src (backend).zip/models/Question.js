import mongoose from "mongoose";

const questionSchema = new mongoose.Schema({
  category: { type: String, required: true, enum: ["Quantitative Aptitude", "Logical Reasoning", "Verbal Ability"] },
  difficulty: { type: String, required: true, enum: ["Easy", "Medium", "Hard"], default: "Easy" },
  question: { type: String, required: true, trim: true },
  options: { type: [String], required: true, validate: value => value.length === 4 },
  correctAnswer: { type: Number, required: true, min: 0, max: 3 },
  explanation: { type: String, required: true }
}, { timestamps: true });

export default mongoose.model("Question", questionSchema);
