import { Router } from "express";
import Question from "../models/Question.js";
import { starterQuestions } from "../data/questions.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const category = req.query.category;
    const limit = Math.min(Math.max(Number.parseInt(req.query.limit || "10", 10) || 10, 1), 30);
    const filter = category && category !== "All categories" ? { category } : {};
    let questions = await Question.find(filter).select("-correctAnswer -explanation").lean();

    if (questions.length === 0) {
      questions = starterQuestions
        .filter(item => !category || category === "All categories" || item.category === category)
        .map((item, index) => ({ ...item, _id: `starter-${index + 1}` }));
    }

    questions = questions.sort(() => Math.random() - 0.5).slice(0, limit);
    res.json({ questions });
  } catch (error) {
    next(error);
  }
});

router.post("/answers", async (req, res, next) => {
  try {
    const { answers } = req.body;
    if (!Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ message: "Please submit at least one answer." });
    }

    const ids = answers.map(item => item.questionId).filter(id => typeof id === "string" && !id.startsWith("starter-"));
    const dbQuestions = ids.length ? await Question.find({ _id: { $in: ids } }).lean() : [];
    const allQuestions = new Map(dbQuestions.map(item => [String(item._id), item]));
    const starterMap = new Map(starterQuestions.map((item, index) => [`starter-${index + 1}`, item]));

    const review = answers.map(item => {
      const question = allQuestions.get(String(item.questionId)) || starterMap.get(String(item.questionId));
      if (!question) return null;
      const selectedAnswer = Number.isInteger(item.selectedAnswer) ? item.selectedAnswer : null;
      const isCorrect = selectedAnswer === question.correctAnswer;
      return {
        questionId: String(item.questionId),
        question: question.question,
        options: question.options,
        selectedAnswer,
        correctAnswer: question.correctAnswer,
        isCorrect,
        explanation: question.explanation,
        category: question.category
      };
    }).filter(Boolean);

    const correct = review.filter(item => item.isCorrect).length;
    res.json({
      total: review.length,
      correct,
      incorrect: review.length - correct,
      scorePercent: review.length ? Math.round((correct / review.length) * 100) : 0,
      review
    });
  } catch (error) {
    next(error);
  }
});

export default router;
